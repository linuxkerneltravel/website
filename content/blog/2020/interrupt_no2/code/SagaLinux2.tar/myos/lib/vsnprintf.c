#include "stdarg.h"
#include "sys/types.h"

void vsnprintf (char *str, size_t size, const char *fmt, va_list ap)
{
  char *temp;
  char c;
  size_t len = size;
  int i,j,sign = 0;
  int num;
  char numbers[] = {'0','1', '2', '3', '4', '5', '6', '7', '8', '9'};
  char strnumber[] = "           "; // :) max 11 digit with the sign.
  
  while (*fmt && len)
    {
      if(*fmt != '%')
	{
	  *str++ = *fmt++;
	  len--;
	  continue;
	}
      fmt++;
      switch (*fmt++){
      case 'c':	
	*str++ = (unsigned char)va_arg(ap,int);
	len--;
	break;
      case 'i':
      case 'd':
	num = va_arg(ap,int);
	if (num < 0)
	  {
	    num *= -1;
	    sign = 1;
	  }
	for(i = 0; i < 11; i++){
	  if(num < 10) 
	    {
	      strnumber[i] = numbers[num];
	      break;
	    }
	  strnumber[i] = numbers[num % 10];
	  num = num / 10;
	}
	if(sign--)
	    strnumber[++i] = '-';
      	for(j = i; j >= 0 && len>0; j--,len--)
	  *str++ = strnumber[j];
	break;
	case 's':
	  temp = va_arg(ap,char*);
	  while((c = *temp++) != '\0')
	    *str++ = c;
	  break;
	default:
	  break;
      }  
    }
  *str='\0';
}


void snprintf (char *str, size_t size, const  char  *format,...)
{
  va_list args;
  va_start(args,format);
  vsnprintf(str, size, format, args);
  va_end(args);  

}

void sprintf (char *str, const  char  *format,...)
{
  va_list args;
  va_start(args,format);
  vsnprintf(str, 0xFFFFFFFFUL, format, args);
  va_end(args);  
}

