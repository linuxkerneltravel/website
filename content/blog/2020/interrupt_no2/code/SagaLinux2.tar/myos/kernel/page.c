#include "kernel/page.h"
#include "asm/system.h"


void page_init()
{
  int pages = NR_PGT;
  unsigned int page_offset = PAGE_OFFSET;
  unsigned int* pgd = PGD_BASE;
  unsigned int phy_add = 0x0000;
  unsigned int* pgt_entry = (unsigned int*)0x2000;
  
  while (pages--)
    {
      *pgd++ = page_offset |PTE_USR|PTE_RW|PTE_PRE;
      page_offset += 0x1000;
    }

  pgd = PGD_BASE;

  while (phy_add < 0x1000000) {
    *pgt_entry++ = phy_add |PTE_USR|PTE_RW|PTE_PRE;
    phy_add += 0x1000;
  }

  __asm__ __volatile__ ("movl %0, %%cr3;"
			"movl %%cr0, %%eax;"
			"orl  $0x80000000, %%eax;"
			"movl %%eax, %%cr0;"::"r"(pgd):"memory","%eax");

  invalidate_tlb();
}
