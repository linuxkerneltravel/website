#include "kernel/console.h"
#include "sys/types.h"
#include "asm/system.h"
#include "asm/io.h"

#define SCREEN 0xB8000
#define MAXLINES 25
#define MAXCOLUMNS 80
#define NEXTLINE 160

static unsigned int cur_pos = 0;
static unsigned int cur_x,cur_y;
static char* scr_origin = (char*)SCREEN;
static ushort_t video_cont_reg = 0x3d4;   // Video Controller Chip 6845
static ushort_t video_cont_val = 0x3d5;

void set_cursor()
{
  cli();
  outb(14, video_cont_reg);
  outb((cur_pos>>9) & 0xFF, video_cont_val);
  outb(15, video_cont_reg);
  outb(cur_pos>>1 & 0xFF, video_cont_val);
  sti();
}

void con_write(char* message, char attr)
{
  unsigned int pos = cur_x * 2 + cur_y * NEXTLINE;
  char c;

  while ((c = *message++) != '\0') {
    switch (c) {
      case '\n':
	  pos += (NEXTLINE - pos % NEXTLINE);
	  cur_y++;
	  cur_x = 0;
	  break;
      case '\b':
	pos -= 2;
	cur_x--;
	 *(scr_origin + pos) = ' ';
	break;
    default:
      *(scr_origin + pos) = c;
      *(scr_origin + pos + 1) = attr;
      cur_x++;
      pos += 2;
    }
  }
  cur_pos = pos;
  set_cursor();
}

void con_clear()
{
  int i;
  int scr_buffer = MAXLINES * MAXCOLUMNS * 2; 

  for (i = 0; i < scr_buffer; i+=2)
    *(scr_origin + i) = ' ';

  cur_x = 0;
  cur_y = 0; 
}

void scroll_up()
{
  
}

void scroll_down()
{
  
}

void goto_xy(unsigned int x, unsigned int y)
{
  if (x > MAXCOLUMNS || y > MAXLINES)
    return;
  cur_x = x;
  cur_y = y;
}

