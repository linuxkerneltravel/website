#include "kernel/idt.h"
#include "kernel/page.h"
#include "kernel/kernel.h"
#include "kernel/keyboard.h"
#include "kernel/timer.h"
#include "kernel/console.h"

int main(void)
{
  int i;
  
  char* message = "\nWelcome\n";
  char* kernel_release = "Kernel 0.0.2 on an i386\n\n";
  char* fake_login = "[SagaLinux]# ";

  char* timer_msg = "\n Add timer!\n";
  //  page_init();
  trap_init();
  printk("%s", timer_msg);
  timer_init();
  keyboard_init();
  //con_clear();

  printk("%s",message);
  printk("%s",kernel_release);
  printk("%s",fake_login);
  i = uptime();
  printk("%d", i);
  //  i = 3 / 0;
  while(1)
    {
      int temp = uptime();
      if (temp != i)
      {
	printk(" %d ", temp);
        i = temp;
      }
    }
  return 0;
}
