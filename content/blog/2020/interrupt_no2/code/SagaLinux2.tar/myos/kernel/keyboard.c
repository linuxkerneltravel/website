#include "kernel/irq.h"
#include "kernel/kernel.h"
#include "asm/io.h"
#include "sys/types.h"

static byte shift = 0;

#define LEFTSHIFT 0x2A
#define RIGHTSHIFT 0x36


static byte keymap[] = { /* SHIFT OFF */ \
		     ' ',' ', '1', '2', '3', '4', '5', '6', '7', '8',
		     '9', '0', '-', '=', '\b', '\t', 'q', 'w', 'e', 'r',
                      't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',  ' ',
                      'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
                      '\'', '~', ' ', '\"', 'z', 'x', 'c', 'v', 'b', 'n',
                      'm', '<', '>', '/', ' ', ' ', ' ', ' ', ' ',
			 /* SHIFT ON */
		      ' ', ' ', '!', '@', '#', '$', '%', '^', '&', '*',
                      '(', ')', '_', '+', ' ', ' ', 'Q', 'W', 'E', 'R',
                      'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', ' ',  ' ',
                      'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':',
                      '\"', '<', ' ', '"', 'Z', 'X', 'C', 'V', 'B', 'N',
                      'M', '<', '>', '?', ' ', ' ', ' ', ' ', ' '};


void keyboard_handler()
{
  byte scancode = inb(0x60);
  byte ascii = 0;
  
  switch (scancode) {
  case LEFTSHIFT:
  case RIGHTSHIFT:
    shift = 0x3B;         // Nothing special.
    break;
  case LEFTSHIFT | 0x80:
  case RIGHTSHIFT | 0x80:
    shift = 0;
    break;
  default:
      if (scancode < 0x3B)
	{
	  ascii = keymap[scancode + shift];
	  printk("%c",ascii);
	}
  }
}

void keyboard_init()
{
  request_irq(KEYBOARD, keyboard_handler);
}

