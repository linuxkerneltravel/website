#include "kernel/irq.h"
#include "asm/io.h"

void enable_irq(int irq)
{
  if (irq > 8)
    outb(inb(SLAVE)&(~(1<<irq)),SLAVE);
  else
    outb(inb(MASTER)&(~(1<<irq)),MASTER);  
}

void disable_irq(int irq)
{
  if (irq > 8)
    outb((inb(SLAVE)|irq),SLAVE);
  else
    outb((inb(MASTER)|irq),MASTER);
}

void request_irq(int irq, void (*handler)())
{
  irq_handler[irq] = handler;
  enable_irq(irq);
}
