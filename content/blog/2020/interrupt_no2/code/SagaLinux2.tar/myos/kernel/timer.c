#include "kernel/timer.h"
#include "kernel/irq.h"
#include "kernel/kernel.h"
#include "asm/io.h"
#include "sys/types.h"

static volatile ulong_t counter;

void timer_handler()
{
  counter += 10;
  //  printk("%c",timer_interrupt_times);
}

void timer_init()
{
  ushort_t pit_counter = CLOCK_RATE * INTERVAL / SECOND;
  counter = 0;

  outb (SEL_CNTR0|RW_LSB_MSB|MODE2|BINARY_STYLE, CONTROL_REG);
  outb (pit_counter & 0xFF, COUNTER0_REG);
  outb (pit_counter >> 8, COUNTER0_REG);

  request_irq(TIMER, timer_handler);
}

ulong_t uptime()
{
  return counter;
}

