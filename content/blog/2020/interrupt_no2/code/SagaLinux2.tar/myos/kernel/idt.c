#include "kernel/idt.h"
#include "kernel/kernel.h"
#include "asm/system.h"

extern void __irq0(void);
extern void __irq1(void);

void trap_init()
{
  int i;
  idtr_t idtr;
  set_trap_gate(0, (unsigned int)&divide_error);
  set_trap_gate(1, (unsigned int)&debug);
  set_trap_gate(2, (unsigned int)&nmi);
  set_trap_gate(3, (unsigned int)&int3);
  set_trap_gate(4, (unsigned int)&overflow);
  set_trap_gate(5, (unsigned int)&bounds);
  set_trap_gate(6, (unsigned int)&invalid_op);
  set_trap_gate(7, (unsigned int)&device_not_available);
  set_trap_gate(8, (unsigned int)&double_fault);
  set_trap_gate(9, (unsigned int)&coprocessor_segment_overrun);
  set_trap_gate(10,(unsigned int) &invalid_TSS);
  set_trap_gate(11, (unsigned int)&segment_not_present);
  set_trap_gate(12, (unsigned int)&stack_segment);
  set_trap_gate(13, (unsigned int)&general_protection);
  set_trap_gate(14, (unsigned int)&page_fault);
  set_trap_gate(15, (unsigned int)&coprocessor_error);
  set_trap_gate(16, (unsigned int)&alignment_check);

  for (i = 17;i<32;i++)
    set_trap_gate(i, (unsigned int)&reserved);

  set_trap_gate(32, (unsigned int)&__irq0);  
  set_trap_gate(33, (unsigned int)&__irq1);
 
  idtr.limit = 34*8;
  idtr.lowerbase = 0x0000;
  idtr.higherbase = 0x0000;
  cli();
  __asm__ __volatile__ ("lidt (%0)"
			::"p" (&idtr)); 
  sti();
}

void set_trap_gate(int vector, unsigned int handler_offset)
{
  trapgd_t* trapgd = (trapgd_t*) IDT_BASE + vector;
  trapgd->loffset = handler_offset & 0x0000FFFF;
  trapgd->segment_s = CODESEGMENT;
  trapgd->reserved = 0x00;
  trapgd->options =  0x0F | PRESENT | KERNEL_LEVEL;
  trapgd->hoffset = ((handler_offset & 0xFFFF0000) >> 16);
  
}

void set_int_gate(int vector,  unsigned int handler_offset)
{
  intgd_t* intgd = (intgd_t*) IDT_BASE + vector;
  intgd->loffset =  handler_offset & 0x0000FFFF;
  intgd->segment_s = CODESEGMENT;
  intgd->reserved = 0x0;
  intgd->options =  0x0E | PRESENT | KERNEL_LEVEL;
  intgd->hoffset = ((handler_offset & 0xFFFF0000) >> 16);  
}

void set_task_gate(int vector, ushort_t tss)
{
  taskgd_t* taskgd = (taskgd_t*) IDT_BASE + vector;
  taskgd->reserved = 0x0;
  taskgd->tss = tss;

  taskgd->reservedd = 0x0;
  taskgd->options = 0x05 | PRESENT | KERNEL_LEVEL;
  taskgd->reserveddd = 0x0;
  
}

// Nooooo... just sleep :)
void sleep(char* message)
{
  printk("%s",message);
  while(1);
}

void divide_error(void)
{
  sleep("divide error");
}
void debug(void)
{
  sleep("debug");
}

void nmi(void)
{
  sleep("nmi");
}

void int3(void)
{
  sleep("int3");
}

void overflow(void)
{
  sleep("overflow");
}

void bounds(void)
{
  sleep("bounds");
}
void invalid_op(void)
{
  sleep("invalid op");
}

void device_not_available(void)
{
  sleep("device not available");
}

void double_fault(void)
{
  sleep("double fault");
}

void coprocessor_segment_overrun(void)
{
  sleep("coprocessor segment overrun");
}

void invalid_TSS(void)
{
  sleep("invalid TSS");
}

void segment_not_present(void)
{
  sleep("segment not present");
}

void stack_segment(void)
{
  sleep("stack segment");
}

void general_protection(void)
{
  sleep("general protection");
}

void page_fault(void)
{
  sleep("page fault");
}

void coprocessor_error(void)
{
  sleep("coprocessor error");
}

void alignment_check(void)
{
  sleep("alignment check");
}

void reserved(void)
{
  sleep("reserved");
}
