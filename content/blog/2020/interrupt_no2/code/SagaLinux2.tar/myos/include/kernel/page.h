#ifndef __PAGE_H__
#define __PAGE_H__

#define NR_PGT 0x4
#define PGD_BASE (unsigned int*)0x1000
#define PAGE_OFFSET (unsigned int)0x2000

#define PTE_PRE 0x01 /* Page present */
#define PTE_RW  0x02 /* Page Readable/Writeable */
#define PTE_USR 0x04 /* User Privilege Level*/ 



void page_init();


#endif
