#ifndef __TIMER_H__
#define __TIMER_H__

#include "sys/types.h"

#define CLOCK_RATE 1193180 /* Clock frequency of the Programmable Interval Timer in HZ */
#define INTERVAL   10      /* 10 msec  */
#define SECOND     1000    /* 1 second is 1000 msec */

/* Register I/O Addresses */
#define COUNTER0_REG  0x40
#define COUNTER1_REG  0x41
#define COUNTER2_REG  0x42
#define CONTROL_REG   0x43

/* Control Word Format */
#define BINARY_STYLE 0x00
#define BCD_STYLE    0x01

#define MODE0        0x00
#define MODE1        0x02
#define MODE2        0x04
#define MODE3        0x06
#define MODE4        0x08
#define MODE5        0x0A

#define SEL_CNTR0    0x00
#define SEL_CNTR1    0x40
#define SEL_CNTR2    0x80
#define SEL_CNTR3    0xC0

#define RW_LATCH     0x00
#define RW_LSB_ONLY  0x01
#define RW_MSB_ONLY  0x02
#define RW_LSB_MSB   0x04

void timer_init();
void timer_handler();
ulong_t uptime();


#endif
