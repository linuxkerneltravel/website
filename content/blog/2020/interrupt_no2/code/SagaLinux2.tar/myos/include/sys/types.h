#ifndef __TYPES_H__
#define __TYPES_H__

typedef unsigned int    __u32;
typedef unsigned short  __u16;
typedef unsigned char   __u8;


#ifndef _SIZE_T
#define _SIZE_T
typedef unsigned int size_t;
#endif

typedef unsigned short ushort_t;
typedef unsigned long ulong_t;
typedef unsigned char byte;
typedef enum {FALSE, TRUE} bool;

#define FALSE (unsigned int)0
#define TRUE  (unsigned int)1
#define NULL ((void *)0)

#endif
