#ifndef __STDDEF_H__
#define __STDDEF_H__

#undef NULL
#define NULL ((void *)0)

#endif
