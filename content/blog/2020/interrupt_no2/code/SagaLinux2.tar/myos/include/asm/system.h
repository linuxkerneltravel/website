#ifndef __ASM_SYSTEM_H_
#define __ASM_SYSTEM_H_

#define sti() __asm__ __volatile__ ("sti":::"memory")
#define cli() __asm__ __volatile__ ("cli":::"memory")

#define invalidate_tlb() __asm__ __volatile__("movl %%cr3,%%eax;"\
					      "movl %%eax,%%cr3;"\
					      :::"%eax")
#endif
