#ifndef __CONSOLE_H__
#define __CONSOLE_H__

void con_write(char *p, char attr);
void con_clear();
void scroll_up();
void scroll_down();
void goto_xy();

#endif
