#ifndef __KERNEL_H_
#define __KERNEL_H_
#include "stdarg.h"
#include "sys/types.h"

void vsnprintf (char *buf, size_t size, const char *fmt,va_list ap);
void printk (const char* fmt,...);

#endif
