#ifndef __IO_H__
#define __IO_H__


#define outb(value,port) __asm__ __volatile__ ("out %%al,%%dx;"::"d"(port),"a"(value))
#define inb(port) ({unsigned char value;__asm__ __volatile__ ("in %%dx,%%al;":"=a"(value):"d"(port));value;})

#define outw(value,port) __asm__ __volatile__ ("out %%ax,%%dx;"::"d"(port),"a"(value))
#define inw(port) ({unsigned short int value;__asm__ __volatile__ ("in %%dx,%%ax;":"=a"(value):"d"(port));value;})

#endif
