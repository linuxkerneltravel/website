#ifndef __STRARG_H__
#define __STRARG_H__

typedef char* va_list;

// Implicit type conversion occurs in argument passing. In order to use the arguments 
// in an argument list where the parameters are pushed to stack, the sizes of the arguments has to be known.
// In printf you can use %d for char short int and int. Thats because all are converted to int. 
// !!!!!!!! Implicit type conversion occurs if the prototype does not specify a type... the prototype of 
// printf(const char* fmt,...) does not specify a type for arguments so all are promoted...

#define __va_size(type) \
   (((sizeof(type) + sizeof(long) - 1) / sizeof (long)) * sizeof (long))

#define va_start(ap, last) \
   ((ap) = ((char*)&last) + __va_size(last))

#define va_arg(ap, type) \
   (*(type*)((ap)+= __va_size(type), (ap) - __va_size(type)))

#define va_end(va_list) ((void)0)

#endif
