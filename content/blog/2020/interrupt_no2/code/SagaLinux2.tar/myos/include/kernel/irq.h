#ifndef __IRQ_H__
#define __IRQ_H__

#define MASTER 0x21
#define SLAVE 0xA1
#define TIMER 0x00
#define KEYBOARD 0x01

void enable_irq(int irq);
void disable_irq(int irq);

void request_irq(int irq,void(*handler)());

void (*irq_handler[16])();

#endif
