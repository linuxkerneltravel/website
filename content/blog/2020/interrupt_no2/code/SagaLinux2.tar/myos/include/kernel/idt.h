#ifndef __IDT_H__
#define __IDT_H__

#include "sys/types.h"

//Interrupt Gate Descriptor
typedef struct intgd_tag
{

  ushort_t loffset;
  ushort_t segment_s;
  byte reserved;               /* Actually 000Reserved */
  byte options;                /* P   DPL   01110      */
  ushort_t hoffset;
  
} intgd_t;

//Task Gate Desctriptor
typedef struct taskgd_tag
{

  ushort_t reserved;
  ushort_t tss;
  byte reservedd;
  byte options;               /* P  DPL  00101 */
  ushort_t reserveddd;

} taskgd_t;

//Trap Gate Descriptor
typedef struct trapgd_tag
{

  ushort_t loffset;
  ushort_t segment_s;
  byte reserved;             /* Actually 000 Reserved */
  byte options ;             /* P  DPL  01111 */
  ushort_t hoffset;

} trapgd_t;

typedef struct idtr_tag
{
  ushort_t limit;
  ushort_t lowerbase;
  ushort_t higherbase;
} idtr_t;

#define IDT_BASE      0x0000 //Interrupt Descriptor Table Base
#define CODESEGMENT   0x08 // Kernel Code Segment 
#define PRESENT       0x80 // Page Present
#define NOTPRESENT    0x00 // Page Not Present
#define KERNEL_LEVEL  0x00
#define USER_LEVEL    0x60
  
void set_trap_gate(int vector, unsigned int handler);
void set_task_gate(int vector, ushort_t tss);
void set_int_gate(int vector, unsigned int handler);

void trap_init();

void theend(char* message);
/* Handlers */
void divide_error(void);
void debug(void);
void nmi(void);
void int3(void);
void overflow(void);
void bounds(void);
void invalid_op(void);
void device_not_available(void);
void double_fault(void);
void coprocessor_segment_overrun(void);
void invalid_TSS(void);
void segment_not_present(void);
void stack_segment(void);
void general_protection(void);
void page_fault(void);
void coprocessor_error(void);
void alignment_check(void);
void reserved(void);

#endif

