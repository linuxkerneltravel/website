#ifndef __KEYBOARD_H__
#define __KEYBOARD_H__

void keyboard_init();
void keyboard_handler();

#endif
