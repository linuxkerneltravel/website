#!/bin/bash

#zero ramdisk
echo -e "Zero the ramdisk..."
if [ ! -f /dev/ram ]; then
	mknod /dev/ram b 1 4 2>/dev/null
fi

ram_size=20000
dd if=/dev/zero of=/dev/ram bs=1k count=$ram_size
#create ext2 fs in ramdisk
echo -e "Creating the ext2 file system in ramdisk..."
mke2fs -m0 /dev/ram $ram_size >/dev/null

echo -e "Create a temp directory..."
rm -rf tmp
mkdir tmp
echo -e "Mount the ramdisk in the temp directory"
umount /dev/ram 2>/dev/null
mount /dev/ram tmp

CURDIR=`pwd`
ROOTDIR=$CURDIR/rootfs

echo -e "Copy the root file system to the ramdisk..."
if [ ! -d $ROOTDIR ]; then
	echo -e "Not found the root file system"
	echo -e "Do you have created the root file system?"
	exit 1
fi
cp -av $ROOTDIR/* tmp 

ramsize=`df tmp|sed -e '1d'|awk '{print $2}'` 
echo -e "The size of ramdisk is $ramsize"
echo -e "Unmount the ramdisk and delete the temp directory"
umount /dev/ram
rm -rf tmp

RAMIMAGE=ramlinux.img
RAMFILE=$RAMIMAGE.gz
echo -e "Create a image for the ramdisk..."
dd if=/dev/ram of=$RAMIMAGE bs=1k count=$ramsize
echo -e "Compress the image..."
if [ -f $RAMFILE ];then 
	rm -f $RAMFILE
fi 
gzip -9v $RAMIMAGE

echo -e "Step 2: create the initrd image..."
INITRDDIR=$CURDIR/initrdfs

#zero ramdisk
echo -e "Zero the ramdisk..."
dd if=/dev/zero of=/dev/ram bs=1k count=4096
#create ext2 fs in ramdisk
echo -e "Creating the ext2 file system in ramdisk..."
mke2fs -m0 /dev/ram 4096 >/dev/null

echo -e "Create a temp directory"
rm -rf tmp
mkdir tmp
echo -e "Mount the ramdisk in the temp directory"
umount /dev/ram 2>/dev/null
mount /dev/ram tmp
echo -e "Copy the initrd file system to the ramdisk..."
cp -av $INITRDDIR/* tmp >/dev/null
ramsize=`df tmp|sed -e '1d'|awk '{print $2}'` 
echo -e "The size of ramdisk is $ramsize"
echo -e "Unmount the ramdisk and delete the temp directory"
umount /dev/ram
rm -rf tmp

INITRDIMAGE=initrd.img
INITRDFILE="$INITRDIMAGE.gz"
echo -e "Create a image for the ramdisk..."
dd if=/dev/ram of=$INITRDIMAGE bs=1k count=$ramsize
echo -e "Compress the image..."
if [ -f $INITRDFILE ];then
	rm -f $INITRDFILE
fi
gzip -9v $INITRDIMAGE


#Add a entry in lilo.conf
MYLILO=mylilo.conf
cp -f /etc/lilo.conf $MYLILO

echo -e "\n" >>$MYLILO
echo -e "image=$CURDIR/myboot/bzImage" >>$MYLILO
echo -e "\tlabel=mylinux" >>$MYLILO
echo -e "\tinitrd=$CURDIR/$INITRDFILE" >>$MYLILO
echo -e "\tread-only" >>$MYLILO
echo -e "\troot=/dev/ram" >>$MYLILO
echo -e "\tappend=\"ramdisk_size=$ram_size\"" >>$MYLILO

lilo -C $CURDIR/$MYLILO 
