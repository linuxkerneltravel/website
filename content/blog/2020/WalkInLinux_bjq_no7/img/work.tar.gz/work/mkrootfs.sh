#!/bin/bash

CURDIR=`pwd`
WORKDIR=$CURDIR/rootfs

echo -e "Read config info"
. config

echo -e "Delete the direcotory first if needed..."
rm -rf $WORKDIR
echo -e "Creating working directory and change to there";
mkdir -p $WORKDIR

cd $WORKDIR;

echo -e "Creating all needed directories";
mkdir $ROOTDIRS;
cd usr;mkdir $USRDIRS;cd -;
mkdir -p $WORKDIR/var/lock/subsys

CopyBinLib()
{
	local src=$1 # src=/bin
	local dst=$2 # dst=/tmp/work/bin
	local files=$3 # "a b c"
	eval files=\$$files
cd $src;cp $files $dst;cd -;
cd $dst
for i in *
do
	ret=`ldd $i|awk '/not a dynamic executable/ {print "yes"}'`
	if [ -z $ret ]; then
		
		for j in `ldd $i|awk '{print \$3}'`
		do
			basedir=`dirname $j` # /lib/i686
			real=`ls -l $j|awk '{print $11}'` # libabc.so.2.5
			if [ ! -d $WORKDIR$basedir ]; then
				mkdir -p $WORKDIR$basedir
			fi
			if [ ! -e $WORKDIR$basdir/$j ] ;then
				echo -e "copy $j to $WORKDIR$basedir"
				cp -f -l $j $WORKDIR$basedir
			fi
			if [ -n $real ]; then
			if [ ! -e $WORKDIR$basedir/$real ]; then
				echo -e "copy $basedir/$real to $WORKDIR$basedir"
				cp -f $basedir/$real $WORKDIR$basedir
			fi
			fi
                       
		done
	fi
done

	
	
}

echo -e "Copy all utils and related libraries..."
CopyBinLib /bin $WORKDIR/bin "BINFILES"
CopyBinLib /sbin $WORKDIR/sbin "SBINFILES"
CopyBinLib /usr/bin $WORKDIR/usr/bin "USRBINFILES"
CopyBinLib /usr/sbin $WORKDIR/usr/sbin "USRSBINFILES"

echo -e "Copy devices for rootfs..."
cd /dev
cp -dpR $DEVFILES $WORKDIR/dev

cd $CURDIR

echo -e "copy system profiles and scripts..."
cp -R myetc/* $WORKDIR/etc

echo -e "copy root profile files."
cp myroot/{.bashrc,.bash_profile} $WORKDIR/root

echo -e "Copy kernel modules..."
cp -R myboot/modules $WORKDIR/lib
echo -e "copy pam dynamic library and modules..."
cp -R /lib/security $WORKDIR/lib

echo -e "copy some dynamic libs for nss"
cp -R /lib/libns* $WORKDIR/lib

echo -e "Discard symbols from the libraries..."
strip -s $WORKDIR/lib/* 2>/dev/null
strip -s $WORKDIR/lib/i686/* 2>/dev/null
strip -s $WORKDIR/lib/security/* 2>/dev/null

echo -e "Discard symbols form commands..."
strip -s $WORKDIR/bin/* 2>/dev/null
strip -s $WORKDIR/sbin/* 2>/dev/null
strip -s $WORKDIR/usr/bin/* 2>/dev/null
strip -s $WORKDIR/usr/sbin/* 2>/dev/null

echo -e "Create the library cache"
ldconfig -r $WORKDIR


