#!/bin/bash
# make dir

CURDIR=`pwd`
INITFSDIR=initrdfs
echo -e "make directortis for init system"
rm -rf $INITFSDIR
mkdir -p ./$INITFSDIR/{bin,lib,dev,proc,etc,mnt,sysroot}
ln -s bin ./$INITFSDIR/sbin

echo "Copy bin and depending lib "
cd $INITFSDIR/bin
cp /sbin/{nash,insmod} .
cp /bin/zcat .
for i in *
do
	ret=`ldd $i|awk '/not a dynamic/ {print "yes"}'`
	if [ -z $ret ]; then
		
		for j in `ldd $i|awk '{print \$3}'`
		do
			basedir=`dirname $j`
			real=`ls -l $j|awk '{print $11}'`
			echo -e "real file is $real"
			if [ ! -d $CURDIR/$INITFSDIR$basedir ]; then
				mkdir -p $CURDIR/$INITFSDIR$basedir
			fi
			echo -e "copy $j to $CURDIR/$INITFSDIR$basedir"
			cp -f -l $j $CURDIR/$INITFSDIR$basedir
			echo -e "copy $basedir/$real to $CURDIR/$INITFSDIR$basedir"
			cp -f $basedir/$real $CURDIR/$INITFSDIR$basedir
                       
		done
	fi
done
#ln -s nash modprobe
echo "Creat dev "
cd $CURDIR
cd $INITFSDIR/dev
cp -dpR /dev/{console,ram,sda,ram1,null,systty,tty0,tty2,tty3,tty4} .
partition=`cat /etc/fstab|awk '{if($2 == "/") print $1}'`
fstype=`cat /etc/fstab|awk '{if($2 == "/") print $3}'`
cp -dpR $partition .

cd $CURDIR
cd $INITFSDIR
echo "script linuxrc"
touch linuxrc
chmod +x linuxrc


echo -e "#!/bin/nash\n" >linuxrc
echo -e "echo Mount sda1 fs">>linuxrc
echo -e "mount -o defaults --rw -t $fstype $partition /mnt\n">>linuxrc
echo -e "echo \"zcat to ram\"">>linuxrc
echo -e "zcat /mnt$CURDIR/ramlinux.img.gz > /dev/ram\n">>linuxrc
echo -e "echo \"umount $partition\"">>linuxrc
echo -e "umount /mnt">>linuxrc


cd $CURDIR
cd $CURDIR/$INITFSDIR/etc
touch ld.so.conf
touch ld.so.cache

cd $CURDIR
echo "ldconfig lib..."
ldconfig -r $CURDIR/$INITFSDIR

